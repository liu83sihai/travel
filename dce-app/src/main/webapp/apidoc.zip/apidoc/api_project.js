define({
  "title": "旅游项目接口列表",
  "url1": "http://127.0.0.1:8080/dce-app",
  "sampleUrl1": "http://127.0.0.1:8080/dce-app",
  "url": "http://app.zjzwly.com/dce-app",
  "sampleUrl": "http://app.zjzwly.com/dce-app",
  "name": "旅游项目接口",
  "version": "1.0.0",
  "description": "旅游项目接口列表",
  "apidoc": "0.2.0",
  "generator": {
    "name": "apidoc",
    "time": "2018-11-16T03:31:32.528Z",
    "url": "http://apidocjs.com",
    "version": "0.16.1"
  }
});
